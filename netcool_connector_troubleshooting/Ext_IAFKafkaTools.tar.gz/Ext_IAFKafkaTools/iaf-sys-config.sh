#!/bin/bash

RESOURCE=kafka
KAKFA_CLUSTER=iaf-system
KAFKA_AUTH=cp4waiops-cartridge-kafka-auth-0

TARGET_TOPIC=cp4waiops-cartridge.lifecycle.input.alerts

