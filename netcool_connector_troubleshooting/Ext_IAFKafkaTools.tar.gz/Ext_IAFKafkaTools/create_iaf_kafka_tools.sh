#!/bin/bash -x
# 
# Note: Unsure where kafka.ibmevents.ibm.com is obatined...
# Use oc get <resource> to do quick check on the kafka instance
#

source "iaf-sys-config.sh"

DATESTR=`date +"%b%d"`
TIMESTR=`date +"T%H:%M:%S"`

TARGET_TOOL_PATH="$PWD/KafkaTools-$DATESTR$TIMESTR"

SSL_TRUSTSTORE_LOC=""
SSL_TRUSTSTORE_PWD=""
SASL_MECHANISM=""
SASL_JAAS_CONFIG=""

if [ ! -d $TARGET_TOOL_PATH ]; then
    mkdir -p $TARGET_TOOL_PATH
fi

function generateKafkaClientConfig {
    # Template for Kafka client properties
cat  << EOF
security.protocol=SASL_SSL
ssl.protocol=TLSv1.2
ssl.enabled.protocols=TLSv1.2

ssl.truststore.location=$SSL_TRUSTSTORE_LOC
ssl.truststore.password=$SSL_TRUSTSTORE_PWD
sasl.mechanism=$SASL_MECHANISM
sasl.jaas.config=$SASL_JAAS_CONFIG

EOF
}

KC_CA_CERT="ca.cert"
KC_KAFKA_USER=""
KC_KAFKA_PWD=""


JKS_TRUSTSTORE=""

BROKER=""
CLIENT_CONFIG=""

function generateProducerScript {
cat  << EOF
#!/bin/bash
INPUT_FILE=\$1
BROKER=$BROKER
CLIENT_CONFIG=$CLIENT_CONFIG
TOPIC=$TARGET_TOPIC

\$KAFKA_HOME/bin/kafka-console-producer.sh --bootstrap-server \$BROKER \
--producer.config \$CLIENT_CONFIG \
--topic \$TOPIC < \$INPUT_FILE

EOF
}

function generetaKafkacatConfig {
cat  << EOF
ssl.ca.location=$KC_CA_CERT
sasl.mechanisms=$SASL_MECHANISM
sasl.username=$KC_KAFKA_USER
sasl.password=$KC_KAFKA_PWD
EOF
}

function generateConsumerScript {
cat  << EOF
#!/bin/bash
BROKER=$BROKER
KCAT_CONFIG=$KC_CONFIG
TOPIC=$TARGET_TOPIC

kafkacat -X security.protocol=SASL_SSL \
-F \$KCAT_CONFIG \
-b \$BROKER \
-C -t \$TOPIC

EOF
}

function generateTopicListScript {
cat  << EOF
#!/bin/bash
INPUT_FILE=\$1
BROKER=$BROKER
CLIENT_CONFIG=$CLIENT_CONFIG
TOPIC=$TARGET_TOPIC

\$KAFKA_HOME/bin/kafka-topics.sh --list \
--bootstrap-server \$BROKER \
--command-config \$CLIENT_CONFIG

EOF
}

function generateGrpcKafkaEnvVarsScript {
KAFKA_SCRAM_PASSWORD_PATH=$TARGET_TOOL_PATH/scram_password.data
KAFKA_TRUSTSTORE_PASSWORD_PATH=$TARGET_TOOL_PATH/truststore_password.data
echo $KC_KAFKA_PWD > $KAFKA_SCRAM_PASSWORD_PATH
echo $SSL_TRUSTSTORE_PWD > $KAFKA_TRUSTSTORE_PASSWORD_PATH

cat  << EOF
#!/bin/bash
SCRIPT_DIR=\$( cd -- "\$( dirname -- "\${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
export KAFKA_BOOTSTRAP_SERVERS=$BROKER
export KAFKA_SCRAM_USERNAME=$KAFKA_AUTH
export KAFKA_SCRAM_PASSWORD_PATH=\$SCRIPT_DIR/scram_password.data
export KAFKA_TRUSTSTORE_PASSWORD_PATH=\$SCRIPT_DIR/truststore_password.data
export KAFKA_TRUSTSTORE_PATH=\$SCRIPT_DIR/$JKS_TRUSTSTORE_FILENAME

echo
echo "KAFKA_BOOTSTRAP_SERVERS="\$KAFKA_BOOTSTRAP_SERVERS
echo "KAFKA_SCRAM_USERNAME="\$KAFKA_SCRAM_USERNAME
echo "KAFKA_SCRAM_PASSWORD_PATH="\$KAFKA_SCRAM_PASSWORD_PATH
echo "KAFKA_TRUSTSTORE_PASSWORD_PATH="\$KAFKA_TRUSTSTORE_PASSWORD_PATH
echo "KAFKA_TRUSTSTORE_PATH="\$KAFKA_TRUSTSTORE_PATH
echo
EOF
}

echo "Resouce name: "${RESOURCE}
echo "Kafka cluster: "${KAKFA_CLUSTER}
echo "Kafka username: "${KAFKA_AUTH}
echo


echo "Get Kafka auth password..."
kafka_pwd=`oc get secret/${KAFKA_AUTH} -o jsonpath='{.data.password}' | base64 --decode`

echo "Get Kafka authentication type..."
kafka_auth_type=`oc get kafka.ibmevents.ibm.com iaf-system -o=jsonpath='{.spec.kafka.listeners[?(@.name=="external")].authentication.type}{"\n"}'`
echo "Get Kafka Jaas Config..."
kafka_jaas=`oc get secret/${KAFKA_AUTH} -o jsonpath='{.data.sasl\.jaas\.config}' | base64 --decode`

echo "Get Kafka external route..."
##kafka_ext_route=`oc get ${RESOURCE} ${KAKFA_CLUSTER} -o=jsonpath='{.status.listeners[?(@.type=="external")].bootstrapServers}{"\n"}'`
##kafka_ext_route=`oc get route iaf-system-kafka-bootstrap -o=jsonpath='{.spec.host}{"\n"}'`
##kafka_ext_route_port=`oc get route iaf-system-kafka-bootstrap -o=jsonpath='{.spec.port.targetPort}{"\n"}'`

kafka_ext_route=`oc get routes iaf-system-kafka-bootstrap -o=jsonpath='{.status.ingress[0].host}{"\n"}'`
kafka_ext_route_port="443"

BROKER=$kafka_ext_route":"$kafka_ext_route_port
echo "Get Kafka external CA cert..."

#kafka_ca_cert=`oc get ${RESOURCE} ${KAKFA_CLUSTER} -o=jsonpath='{.status.listeners[?(@.type=="external")].certificates}{"\n"}'`
#kafka_ca_cert=`oc get secret kafka-truststore -o yaml | yq '.data."es-truststore.jks"' | sed 's/.\(.*\)/\1/' | sed 's/\(.*\)./\1/' | base64 `

tmpcertname=$TARGET_TOOL_PATH/$(uuidgen)
oc extract secret/iaf-system-cluster-ca-cert --keys=ca.crt --to=- > $tmpcertname;
#kafka_ca_cert=`oc get secret aiopsedge-kafka-application-secret -o yaml | yq '.data."ca.crt"' | sed 's/.\(.*\)/\1/' | sed 's/\(.*\)./\1/' | base64 `

echo "Kafka password: "${kafka_pwd}
echo "Kafka auth type:"${kafka_auth_type}
echo "Kafka Jaas:     "${kafka_jaas}
echo "Kafka route:    "${kafka_ext_route}
echo "Kafka route port:    "${kafka_ext_route_port}
echo "Kafka cert: "
echo ${kafka_ca_cert}

##tmpcertname=$TARGET_TOOL_PATH/$(uuidgen)
##echo ${kafka_ca_cert} | sed 's/\\n/\n/g' | tr -d '"[]' > $tmpcertname

echo "Kafka CA cert: "
cat $tmpcertname
echo

echo "Generate pfx file from $tmpcertname"
keystorepwd="changeme"
pfx_filename="truststore.pfx"
keytool -import -keystore $TARGET_TOOL_PATH/$pfx_filename -storetype PKCS12  -alias CARoot -file $tmpcertname -noprompt -storepass $keystorepwd

JKS_TRUSTSTORE_FILENAME="truststore.jks"
JKS_TRUSTSTORE=$TARGET_TOOL_PATH/$JKS_TRUSTSTORE_FILENAME
echo "Convert pfx to jks"
keytool -importkeystore \
 -srckeystore $TARGET_TOOL_PATH/$pfx_filename \
 -srcstoretype PKCS12 \
 -srcstorepass $keystorepwd \
 -destkeystore $JKS_TRUSTSTORE \
 -deststoretype jks \
 -deststorepass $keystorepwd

echo
echo "Remove $tmpcertname"
mv $tmpcertname $TARGET_TOOL_PATH/$KC_CA_CERT

#echo
#echo "truststore.pfx content: "
#keytool -list -v -keystore "truststore.pfx" -storepass $keystorepwd -storetype PKCS12
#echo

SSL_TRUSTSTORE_LOC=$pfx_filename
SSL_TRUSTSTORE_PWD=$keystorepwd
SASL_MECHANISM=`echo ${kafka_auth_type^^}`
SASL_JAAS_CONFIG=$kafka_jaas

#####################################
# Grpc Log collector Kafka env vars
#####################################
KAFKA_SCRAM_PASSWORD_PATH=$TARGET_TOOL_PATH/scram_password.data
KAFKA_TRUSTSTORE_PASSWORD_PATH=$TARGET_TOOL_PATH/truststore_password.data

CLIENT_CONFIG="kafka_client.properties"
generateKafkaClientConfig > $TARGET_TOOL_PATH/$CLIENT_CONFIG

KC_KAFKA_USER=$KAFKA_AUTH
KC_KAFKA_PWD=$kafka_pwd

KC_CONFIG="kcat.config"
generetaKafkacatConfig > $TARGET_TOOL_PATH/$KC_CONFIG

producer_script="$TARGET_TOOL_PATH/producer_script.sh"
generateProducerScript > $producer_script
chmod +x $producer_script

consumer_script="$TARGET_TOOL_PATH/consumer_script.sh"
generateConsumerScript > $consumer_script
chmod +x $consumer_script

topiclist_script="$TARGET_TOOL_PATH/topiclist_script.sh"
generateTopicListScript > $topiclist_script
chmod +x $topiclist_script

kakfaenv_script="$TARGET_TOOL_PATH/set_grpc_kakfa_env_vars.sh"
generateGrpcKafkaEnvVarsScript > $kakfaenv_script
chmod +x $kakfaenv_script

#echo
#cat kafka_client.properties
#echo
#echo "Test kafka topic listing from broker server $kafka_ext_route"
#echo
#echo "== Start of list =="
#$KAFKA_HOME/bin/kafka-topics.sh --list --bootstrap-server $kafka_ext_route --command-config $kfkclient_props
#echo "== End of list =="
#echo

YELLOW='\033[1;33m'
echo
echo -e "Please check the credentials and kakfa scripts created at ${YELLOW}$TARGET_TOOL_PATH${YELLOW}"
echo
echo "$0 completes here."
echo
