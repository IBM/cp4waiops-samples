
@author: sooncs@my.ibm.com

What is IAFKafkaTool for?
-------------------------
For a given topic, this tool generates these artifacts: 
 - consumer and producer scripts
 - PFX and JKS truststore (i.e cert embedded therein)
 - kafka client configurations

The password to PFX and JKS truststore is 'changeme'.

How to use IAFKafkaTool?
------------------------
Prerequisite: 
- Pass oc login to a OCP cluster 
- Set to the right namespace.

Step:
1. Configure the topic name at the TARGET_TOPIC variable in iaf-sys-config.sh

2. Run create_iaf_kafka_tools.sh
   The consumer & producer scripts and configurations will be 
   in the resultant directory reported at the end of the process.

   Best practice: 
   - Change the resultant directory name for easy reference
     Recommended naming convention:
     <cluster_name>_<topic_name>

3. Verify operability of the scripts and the credential
   Prerequisite: 
   a. Kafka package installed
   b. kafkacat installed
   c. KAFKA_HOME defined (pointing to the Kafka package)
      e.g. KAFKA_HOME=/opt/kafka/kafka_2.12-2.8.0

   - To see the full topic list in the namespace, run
   <resultant-dir>/topiclist_script.sh

   - To consume the topic, run 
   <resultant-dir>/consumer_script.sh

   - To produce data to the topic, run 
   <resultant-dir>/producer_script.sh <data-file>
